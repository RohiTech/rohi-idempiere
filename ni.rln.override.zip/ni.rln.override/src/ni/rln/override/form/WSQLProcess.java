package ni.rln.override.form;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.adempiere.webui.component.Button;
import org.adempiere.webui.component.Textbox;
import org.adempiere.webui.panel.ADForm;
import org.adempiere.webui.util.ZKUpdateUtil;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zul.*;

public class WSQLProcess extends ADForm {

    private static final long serialVersionUID = 1L;
    
    private Textbox m_txbInput = new Textbox();
    private Listbox m_listResults = new Listbox();
    private Label m_lblTime = new Label();
    private Label m_lblRows = new Label();
    private Label m_lblStatus = new Label();
    
    private Button m_btnRun = new Button();
    private Button m_btnClear = new Button();
    private Button m_btnHistory = new Button();
    private Button m_btnExport = new Button();
    
    private Menupopup m_historyPopup = new Menupopup();
    private Menupopup m_exportPopup = new Menupopup();
    private List<String> m_historyList = new ArrayList<>();

    @Override
    protected void initForm() {
        int adUserId = Env.getAD_User_ID(Env.getCtx());
        if (!isSupportUser(adUserId)) {
            this.appendChild(new Label("ACCESO RESTRINGIDO"));
            return;
        }
        setupPopups();
        configureUI();
    }

    private boolean isSupportUser(int adUserId) {
        String sql = "SELECT COUNT(*) FROM AD_User WHERE AD_User_ID = ? AND IsActive = 'Y' AND IsSupportUser = 'Y'";
        return DB.getSQLValue(null, sql, adUserId) > 0;
    }

    private void setupPopups() {
        Object[][] formats = {
            {"Excel (.xls)", "z-icon-file-excel-o", "XLS"},
            {"CSV (.csv)", "z-icon-file-text-o", "CSV"},
            {"SQL (.sql)", "z-icon-database", "SQL"}
        };
        for (Object[] f : formats) {
            Menuitem mi = new Menuitem((String)f[0], (String)f[1]);
            String type = (String)f[2];
            mi.addEventListener(Events.ON_CLICK, e -> exportResults(type));
            m_exportPopup.appendChild(mi);
        }
        this.appendChild(m_historyPopup);
        this.appendChild(m_exportPopup);
    }

    private void configureUI() {
        // Layout principal sin colores fijos
        Borderlayout mainLayout = new Borderlayout();
        ZKUpdateUtil.setHflex(mainLayout, "1");
        ZKUpdateUtil.setVflex(mainLayout, "1");

        // --- TOOLBAR (Usando clases de iDempiere) ---
        North north = new North();
        north.setBorder("none");
        north.setSclass("adform-toolbar"); // Hereda el estilo del tema actual
        
        Hlayout toolbar = new Hlayout();
        toolbar.setValign("middle");
        toolbar.setSpacing("5px");
        toolbar.setStyle("padding: 5px;");

        // Clases CSS de iDempiere para compatibilidad de temas
        m_btnRun.setIconSclass("z-icon-play");
        m_btnRun.setLabel("");
        m_btnRun.setSclass("btn-small btn-primary"); // Color principal del tema
        m_btnRun.addEventListener(Events.ON_CLICK, this);

        m_btnClear.setIconSclass("z-icon-eraser");
        m_btnClear.setSclass("btn-small"); // Estilo neutro del tema
        m_btnClear.setTooltiptext("Limpiar");
        m_btnClear.addEventListener(Events.ON_CLICK, e -> { m_txbInput.setText(""); m_txbInput.focus(); });

        m_btnHistory.setIconSclass("z-icon-history");
        m_btnHistory.setSclass("btn-small");
        m_btnHistory.setPopup(m_historyPopup);

        m_btnExport.setIconSclass("z-icon-download");
        m_btnExport.setSclass("btn-small btn-success"); // Color 'éxito' (verde) del tema
        m_btnExport.setPopup(m_exportPopup);

        toolbar.appendChild(m_btnRun);
        toolbar.appendChild(new Space());
        toolbar.appendChild(m_btnClear);
        toolbar.appendChild(m_btnHistory);
        toolbar.appendChild(new Space());
        toolbar.appendChild(m_btnExport);
        north.appendChild(toolbar);

        // --- CUERPO ---
        Center center = new Center();
        center.setBorder("none");

        Vbox mainVbox = new Vbox();
        mainVbox.setSpacing("0");
        ZKUpdateUtil.setHflex(mainVbox, "1");
        ZKUpdateUtil.setVflex(mainVbox, "1");

        // EDITOR SQL (Sin colores de fondo para que herede el tema)
        m_txbInput.setMultiline(true);
        ZKUpdateUtil.setHflex(m_txbInput, "1");
        ZKUpdateUtil.setVflex(m_txbInput, "1"); 
        m_txbInput.setStyle("font-family: monospace; font-size: 14px;");

        Splitter splitter = new Splitter();
        splitter.setCollapse("after");

        // RESULTADOS (Sin mold paging para evitar problemas de eliminación manual)
        m_listResults.setEmptyMessage("Sin datos");
        ZKUpdateUtil.setHflex(m_listResults, "1");
        ZKUpdateUtil.setVflex(m_listResults, "1");
        // Dejamos el mold por defecto para que use scroll nativo

        mainVbox.appendChild(m_txbInput);
        mainVbox.appendChild(splitter);
        mainVbox.appendChild(m_listResults);
        center.appendChild(mainVbox);

        // --- FOOTER (Barra de estado estándar) ---
        South south = new South();
        south.setBorder("none");
        south.setSclass("adform-status-bar");
        
        Hlayout footer = new Hlayout();
        footer.setValign("middle");
        footer.setSpacing("20px");
        footer.setStyle("padding: 2px 10px;");
        
        m_lblStatus.setSclass("label-status");
        m_lblTime.setSclass("label-info");
        m_lblRows.setSclass("label-info");
        
        footer.appendChild(m_lblStatus);
        footer.appendChild(m_lblTime);
        footer.appendChild(m_lblRows);
        south.appendChild(footer);

        mainLayout.appendChild(north);
        mainLayout.appendChild(center);
        mainLayout.appendChild(south);
        this.appendChild(mainLayout);
    }

    @Override
    public void onEvent(Event event) throws Exception {
        if (event.getTarget().equals(m_btnRun)) executeQuery();
    }

    private void executeQuery() {
        String sql = m_txbInput.getText().trim();
        if (sql.isEmpty()) return;
        
        if (!m_historyList.contains(sql)) { 
            m_historyList.add(0, sql); 
            refreshHistory(); 
        }

        m_listResults.getChildren().clear();
        m_btnRun.setDisabled(true);
        long start = System.currentTimeMillis();

        try (Connection conn = DB.createConnection(true, Connection.TRANSACTION_READ_COMMITTED);
             Statement stmt = conn.createStatement()) {
            
            boolean isRS = stmt.execute(sql);
            if (isRS) {
                int r = populateGrid(stmt.getResultSet());
                updateFooter(System.currentTimeMillis() - start, r, "CONSULTA OK", false);
            } else {
                int affected = stmt.getUpdateCount();
                updateFooter(System.currentTimeMillis() - start, affected, "SENTENCIA EJECUTADA", false);
            }
        } catch (Exception e) {
            updateFooter(0, 0, "ERROR: " + e.getMessage(), true);
        } finally {
            m_btnRun.setDisabled(false);
        }
    }

    private int populateGrid(ResultSet rs) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int cols = md.getColumnCount();
        
        Listhead head = new Listhead();
        head.setSizable(true);
        for (int i = 1; i <= cols; i++) {
            Listheader h = new Listheader(md.getColumnLabel(i));
            h.setHflex("min"); 
            head.appendChild(h);
        }
        m_listResults.appendChild(head);
        
        int count = 0;
        while (rs.next()) {
            Listitem item = new Listitem();
            for (int i = 1; i <= cols; i++) {
                Object val = rs.getObject(i);
                item.appendChild(new Listcell(val == null ? "NULL" : val.toString()));
            }
            m_listResults.appendChild(item);
            count++;
            if (count >= 2000) break; // Límite para evitar colapso del navegador
        }
        return count;
    }

    private void exportResults(String type) {
        if (m_listResults.getItemCount() == 0) return;
        
        StringBuilder sb = new StringBuilder();
        Listhead head = m_listResults.getListhead();
        List<Component> headers = head.getChildren();
        
        String sep = type.equals("CSV") ? "," : "\t";
        for (int i = 0; i < headers.size(); i++) {
            sb.append(((Listheader)headers.get(i)).getLabel()).append(sep);
        }
        sb.append("\n");
        
        for (Listitem row : m_listResults.getItems()) {
            List<Component> cells = row.getChildren();
            for (int i = 0; i < cells.size(); i++) {
                sb.append(((Listcell)cells.get(i)).getLabel()).append(sep);
            }
            sb.append("\n");
        }
        
        String fileName = "SQL_Export_" + System.currentTimeMillis() + "." + type.toLowerCase();
        Filedownload.save(sb.toString().getBytes(), "text/plain", fileName);
    }

    private void refreshHistory() {
        m_historyPopup.getChildren().clear();
        for (String h : m_historyList) {
            String label = h.length() > 50 ? h.substring(0, 47) + "..." : h;
            Menuitem mi = new Menuitem(label, "z-icon-history");
            mi.addEventListener(Events.ON_CLICK, e -> m_txbInput.setText(h));
            m_historyPopup.appendChild(mi);
        }
    }

    private void updateFooter(long t, int r, String s, boolean error) {
        m_lblStatus.setValue(s);
        // El color del error se maneja con estilo, pero el resto hereda del tema
        m_lblStatus.setStyle(error ? "color: #ff4d4f; font-weight: bold;" : "font-weight: bold;");
        m_lblTime.setValue(t + " ms");
        m_lblRows.setValue(r + " registros");
    }
}