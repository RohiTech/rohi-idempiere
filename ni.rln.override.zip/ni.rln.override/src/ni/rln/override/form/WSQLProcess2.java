package ni.rln.override.form;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.adempiere.webui.component.Button;
import org.adempiere.webui.component.Textbox;
import org.adempiere.webui.panel.ADForm;
import org.adempiere.webui.util.ZKUpdateUtil;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.event.Event;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zul.*;

public class WSQLProcess2 extends ADForm {

    private static final long serialVersionUID = 1L;
    
    private Textbox m_txbInput = new Textbox();
    private Listbox m_listResults = new Listbox();
    private Label m_lblTime = new Label();
    private Label m_lblRows = new Label();
    private Label m_lblStatus = new Label();
    
    private Button m_btnRun = new Button();
    private Button m_btnClear = new Button();
    private Button m_btnHistory = new Button();
    private Button m_btnExport = new Button();
    
    private Menupopup m_historyPopup = new Menupopup();
    private Menupopup m_exportPopup = new Menupopup();
    private List<String> m_historyList = new ArrayList<>();

    @Override
    protected void initForm() {
        int adUserId = Env.getAD_User_ID(Env.getCtx());
        if (!isSupportUser(adUserId)) {
            this.appendChild(new Label("ACCESO RESTRINGIDO"));
            return;
        }
        setupPopups();
        configureUI();
    }

    private boolean isSupportUser(int adUserId) {
        String sql = "SELECT COUNT(*) FROM AD_User WHERE AD_User_ID = ? AND IsActive = 'Y' AND IsSupportUser = 'Y'";
        return DB.getSQLValue(null, sql, adUserId) > 0;
    }

    private void setupPopups() {
        String[][] formats = {{"Excel (.xls)", "z-icon-file-excel-o"}, {"CSV (.csv)", "z-icon-file-text-o"}};
        for (String[] f : formats) {
            Menuitem mi = new Menuitem(f[0], f[1]);
            mi.addEventListener(Events.ON_CLICK, e -> exportResults(f[0]));
            m_exportPopup.appendChild(mi);
        }
        this.appendChild(m_historyPopup);
        this.appendChild(m_exportPopup);
    }

    private void configureUI() {
        this.setStyle("background-color: #ffffff; padding: 0; height: 100%; width: 100%;");
        
        Borderlayout mainLayout = new Borderlayout();
        ZKUpdateUtil.setHflex(mainLayout, "1");
        ZKUpdateUtil.setVflex(mainLayout, "1");

        // --- TOOLBAR (Botones discretos con iconos) ---
        North north = new North();
        north.setHeight("50px");
        north.setStyle("background: #f8fafc; border-bottom: 1px solid #e2e8f0; padding: 0 15px;");
        
        Hlayout toolbar = new Hlayout();
        toolbar.setValign("middle");
        toolbar.setSpacing("10px");
        toolbar.setHeight("100%");

        // Estilo común para botones de iconos
        String btnStyle = "background: transparent; border: 1px solid #cbd5e1; color: #64748b; border-radius: 4px; padding: 5px 10px; cursor: pointer; font-size: 16px;";
        
        m_btnRun.setIconSclass("z-icon-play");
        m_btnRun.setTooltiptext("Ejecutar Consulta");
        m_btnRun.setStyle(btnStyle + "color: #2563eb; border-color: #bfdbfe;");
        m_btnRun.addEventListener(Events.ON_CLICK, this);

        m_btnClear.setIconSclass("z-icon-eraser");
        m_btnClear.setTooltiptext("Limpiar Editor");
        m_btnClear.setStyle(btnStyle);
        m_btnClear.addEventListener(Events.ON_CLICK, e -> { m_txbInput.setText(""); m_txbInput.focus(); });

        m_btnHistory.setIconSclass("z-icon-history");
        m_btnHistory.setTooltiptext("Historial de Consultas");
        m_btnHistory.setPopup(m_historyPopup);
        m_btnHistory.setStyle(btnStyle);

        m_btnExport.setIconSclass("z-icon-download");
        m_btnExport.setTooltiptext("Exportar Resultados");
        m_btnExport.setPopup(m_exportPopup);
        m_btnExport.setStyle(btnStyle + "color: #16a34a; border-color: #bbf7d0;");

        toolbar.appendChild(m_btnRun);
        toolbar.appendChild(new Space());
        toolbar.appendChild(m_btnClear);
        toolbar.appendChild(m_btnHistory);
        toolbar.appendChild(new Space());
        toolbar.appendChild(m_btnExport);
        north.appendChild(toolbar);

        // --- CUERPO PRINCIPAL ---
        Center center = new Center();
        center.setStyle("border: none;");

        Vbox mainVbox = new Vbox();
        mainVbox.setSpacing("0");
        mainVbox.setAlign("stretch");
        ZKUpdateUtil.setHflex(mainVbox, "1");
        ZKUpdateUtil.setVflex(mainVbox, "1");

        // EDITOR SQL - SCROLL VERTICAL Y HORIZONTAL PERMANENTE
        m_txbInput.setMultiline(true);
        ZKUpdateUtil.setHflex(m_txbInput, "1");
        ZKUpdateUtil.setVflex(m_txbInput, "1"); 
        m_txbInput.setStyle("font-family: 'Monaco', 'Consolas', monospace; font-size: 14px; " +
                            "border: none; padding: 15px; background: #ffffff; color: #1e293b; " +
                            "line-height: 1.5; outline: none; " +
                            "overflow: scroll !important; white-space: pre !important; word-wrap: normal !important;");

        // Splitter
        Splitter splitter = new Splitter();
        splitter.setStyle("background: #e2e8f0; height: 6px; cursor: ns-resize; border-top: 1px solid #cbd5e1;");

        // RESULTADOS - SCROLL VERTICAL Y HORIZONTAL PERMANENTE
        m_listResults.setEmptyMessage("Sin datos");
        ZKUpdateUtil.setHflex(m_listResults, "1");
        ZKUpdateUtil.setVflex(m_listResults, "1");
        m_listResults.setStyle("border: none; background: #ffffff; overflow: scroll !important;");
        m_listResults.setSizedByContent(false);

        mainVbox.appendChild(m_txbInput);
        mainVbox.appendChild(splitter);
        mainVbox.appendChild(m_listResults);
        center.appendChild(mainVbox);

        // --- FOOTER ---
        South south = new South();
        south.setHeight("35px");
        south.setStyle("background: #f1f5f9; border-top: 1px solid #e2e8f0; padding: 5px 20px;");
        
        Hlayout footer = new Hlayout();
        footer.setValign("middle");
        footer.setSpacing("20px");
        
        String bS = "font-size: 10px; font-weight: bold; color: #64748b; text-transform: uppercase;";
        m_lblStatus.setStyle(bS);
        m_lblTime.setStyle(bS);
        m_lblRows.setStyle(bS);
        
        footer.appendChild(m_lblStatus);
        footer.appendChild(m_lblTime);
        footer.appendChild(m_lblRows);
        south.appendChild(footer);

        mainLayout.appendChild(north);
        mainLayout.appendChild(center);
        mainLayout.appendChild(south);
        this.appendChild(mainLayout);
    }

    @Override
    public void onEvent(Event event) throws Exception {
        if (event.getTarget().equals(m_btnRun)) executeQuery();
    }

    private void executeQuery() {
    	String sql = m_txbInput.getText().trim();
    	if (sql.isEmpty()) return;
        if (!m_historyList.contains(sql)) { m_historyList.add(0, sql); refreshHistory(); }

        m_listResults.getChildren().clear();
        m_btnRun.setDisabled(true);
        long start = System.currentTimeMillis();

        try (Connection conn = DB.createConnection(true, Connection.TRANSACTION_READ_COMMITTED);
        	 Statement stmt = conn.createStatement()) {
            
        	boolean isRS = stmt.execute(sql);
        	if (isRS) {
                int r = populateGrid(stmt.getResultSet());
                updateFooter(System.currentTimeMillis() - start, r, "SELECT OK");
        	} else {
        		int affected = stmt.getUpdateCount();
        		updateFooter(System.currentTimeMillis() - start, affected, "CMD OK");
            }
        } catch (Exception e) {
            m_lblStatus.setValue("ERROR: " + e.getMessage());
            m_lblStatus.setStyle("font-size: 10px; font-weight: bold; color: #ef4444;");
        } finally {
            m_btnRun.setDisabled(false);
        }
    }

    private int populateGrid(ResultSet rs) throws SQLException {
        ResultSetMetaData md = rs.getMetaData();
        int cols = md.getColumnCount();
        Listhead head = new Listhead();
        head.setSizable(true);
        
        for (int i = 1; i <= cols; i++) {
            Listheader h = new Listheader(md.getColumnLabel(i));
            h.setHflex("min"); 
            h.setStyle("background: #f8fafc; font-weight: bold; min-width: 120px; border-bottom: 1px solid #e2e8f0;");
            head.appendChild(h);
        }
        m_listResults.appendChild(head);
        
        int count = 0;
        while (rs.next()) {
            Listitem item = new Listitem();
            for (int i = 1; i <= cols; i++) {
                Object val = rs.getObject(i);
                item.appendChild(new Listcell(val == null ? "NULL" : val.toString()));
            }
            m_listResults.appendChild(item);
            count++;
            if (count >= 10000) break; 
        }
        return count;
    }

    private void exportResults(String format) {
        if (m_listResults.getItemCount() == 0) return;
        StringBuilder sb = new StringBuilder();
        Listhead head = m_listResults.getListhead();
        List<Component> headers = head.getChildren();
        String sep = format.contains("CSV") ? "," : "\t";
        
        for (int i = 0; i < headers.size(); i++) sb.append(((Listheader)headers.get(i)).getLabel()).append(sep);
        sb.append("\n");
        
        for (Listitem row : m_listResults.getItems()) {
            List<Component> cells = row.getChildren();
            for (int i = 0; i < cells.size(); i++) {
                sb.append(((Listcell)cells.get(i)).getLabel()).append(sep);
            }
            sb.append("\n");
        }
        Filedownload.save(sb.toString().getBytes(), "text/csv", "Data_" + System.currentTimeMillis() + ".csv");
    }

    private void refreshHistory() {
        m_historyPopup.getChildren().clear();
        for (String h : m_historyList) {
            String label = h.length() > 50 ? h.substring(0, 47) + "..." : h;
            Menuitem mi = new Menuitem(label, "z-icon-history");
            mi.addEventListener(Events.ON_CLICK, e -> m_txbInput.setText(h));
            m_historyPopup.appendChild(mi);
        }
    }

    private void updateFooter(long t, int r, String s) {
        m_lblStatus.setValue(s);
        m_lblStatus.setStyle("font-size: 10px; font-weight: bold; color: #2563eb;");
        m_lblTime.setValue(t + " MS");
        m_lblRows.setValue(r + " REGS");
    }
}