package ni.rln.override.form;

import org.adempiere.webui.factory.IFormFactory;
import org.adempiere.webui.panel.ADForm;

public class WSQLProcessFactory implements IFormFactory 
{

	@Override
	public ADForm newFormInstance(String formName) {

if(formName.contains("WSQLProcess"))
	return new WSQLProcess();
		
		return null;
	}

}
